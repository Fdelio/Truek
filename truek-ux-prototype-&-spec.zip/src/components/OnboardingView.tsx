/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { OnboardingState } from '../types';
import { INITIAL_INTERESTS } from '../data/mockData';

interface OnboardingViewProps {
  onboardingState: OnboardingState;
  setOnboardingState: React.Dispatch<React.SetStateAction<OnboardingState>>;
  onAdvance: () => void;
  addLog: (title: string, data: any) => void;
}

export default function OnboardingView({
  onboardingState,
  setOnboardingState,
  onAdvance,
  addLog,
}: OnboardingViewProps) {
  const [emailText, setEmailText] = useState('');
  const [passwordText, setPasswordText] = useState('');
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Auto-trigger location simulation
  useEffect(() => {
    if (onboardingState.locationStatus === 'idle') {
      setOnboardingState(prev => ({ ...prev, locationStatus: 'detecting' }));
      addLog('Ubicación: Iniciando geolocalización simulada...', { status: 'detecting' });

      const timer = setTimeout(() => {
        setOnboardingState(prev => ({
          ...prev,
          locationStatus: 'detected',
          locationText: 'Bogotá, Colombia',
        }));
        addLog('Ubicación: Geolocalización exitosa (Coordenadas ficticias: 4.7110, -74.0721)', {
          resolvedLocation: 'Bogotá, Colombia',
          accuracy_meters: 12,
          commercial_district: 'Usaquén'
        });
      }, 1800);
      return () => clearTimeout(timer);
    }
  }, []);

  // Update progress bar
  useEffect(() => {
    let filledFields = 0;
    if (emailText.length > 3) filledFields += 1;
    if (passwordText.length > 5) filledFields += 1;
    if (onboardingState.locationStatus === 'detected') filledFields += 1;
    if (onboardingState.selectedInterests.length > 0) filledFields += 1;

    // Base 15% progress + remaining partitioned up to 100%
    const calculated = 15 + Math.round((filledFields / 4) * 85);
    setOnboardingState(prev => ({ ...prev, progress: calculated }));
  }, [emailText, passwordText, onboardingState.locationStatus, onboardingState.selectedInterests]);

  const handleInterestToggle = (interest: string) => {
    setOnboardingState(prev => {
      const interests = prev.selectedInterests.includes(interest)
        ? prev.selectedInterests.filter(i => i !== interest)
        : [...prev.selectedInterests, interest];
      
      const action = prev.selectedInterests.includes(interest) ? 'remove_interest' : 'add_interest';
      addLog(`Interés: Usuario actualizó tags (${action}: "${interest}")`, {
        current_interests: interests,
      });

      return {
        ...prev,
        selectedInterests: interests,
      };
    });
  };

  const handleManualLocationChange = (zone: string) => {
    setOnboardingState(prev => ({
      ...prev,
      locationStatus: 'detected',
      locationText: zone,
    }));
    addLog(`Ubicación: Zona forzada manualmente por simulación técnica`, {
      resolvedLocation: zone,
      accuracy_meters: 5,
      commercial_district: zone.split(',')[0],
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    addLog('Registro: Enviando payload de autenticación simulada al Sandbox de TrueK', {
      email: emailText,
      password_hashed: 'sha256_fbc8d8eec...' + passwordText.length + '_len',
      detected_location: onboardingState.locationText,
      selected_interests: onboardingState.selectedInterests,
    });

    setTimeout(() => {
      setIsSubmitting(false);
      onAdvance();
    }, 2500);
  };

  const isFormValid = emailText.includes('@') && passwordText.length >= 6;

  return (
    <div className="relative flex flex-col md:flex-row min-h-[700px] w-full bg-[#f8f9fa] overflow-hidden rounded-2xl shadow-inner border border-zinc-200">
      
      {/* Upper Progress Indicator Bar */}
      <div className="absolute top-0 left-0 w-full h-[6px] bg-[#edeeef] z-30">
        <div 
          className="h-full bg-[#00685f] transition-all duration-500 shadow-[0_0_8px_rgba(0,104,95,0.4)]"
          style={{ width: `${onboardingState.progress}%` }}
        />
      </div>

      {/* Hero Left Panel */}
      <section className="relative hidden lg:flex flex-col justify-between w-5/12 p-8 bg-[#008378] text-white overflow-hidden">
        {/* Background Radial Shimmer */}
        <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_50%_40%,rgba(137,245,231,0.25),transparent_65%)]" />

        <div className="relative z-10">
          <span className="font-sans font-bold tracking-widest text-[#89f5e7] hover:scale-105 duration-200 cursor-default block mb-1">TRUEK INTÉLIGENT</span>
          <h1 className="font-sans text-3xl font-extrabold tracking-tight leading-none text-white mb-2">TrueK</h1>
          <p className="font-sans text-sm text-[#f4fffc]/90">Libera el valor de las cosas que ya no usas intercambiando con tu comunidad.</p>
        </div>

        <div className="relative z-10 bg-white/10 backdrop-blur-md rounded-xl p-4 border border-white/20">
          <div className="flex items-center gap-2 mb-1">
            <span className="material-symbols-outlined text-[20px] text-[#89f5e7]">explore</span>
            <span className="text-xs font-bold tracking-wider uppercase text-[#f4fffc]/85">Geolocalización Activa</span>
          </div>
          <p className="text-xs text-white/95">Detección automática de zonas comerciales para emparejarte con vecinos a menos de 5 kilómetros.</p>
        </div>

        <div className="relative z-0 opacity-15 pointer-events-none select-none">
          <svg className="w-full h-auto" viewBox="0 0 200 120" xmlns="http://www.w3.org/2000/svg">
            <path d="M 10,60 Q 50,110 100,60 T 190,60" fill="none" stroke="white" strokeWidth="2" />
            <circle cx="100" cy="60" r="8" fill="white" />
            <circle cx="50" cy="85" r="5" fill="white" />
          </svg>
        </div>
      </section>

      {/* Right Onboarding Content Area */}
      <section className="flex-1 p-6 md:p-8 flex flex-col justify-between">
        <div className="space-y-6">
          <header className="text-center md:text-left">
            <div className="lg:hidden mb-2">
              <span className="font-sans text-2xl font-black text-[#00685f] tracking-tighter">TrueK</span>
            </div>
            <h2 id="onboarding-welcome-title" className="text-2xl font-black text-[#191c1d] leading-none mb-1">Únete a TrueK</h2>
            <p className="text-xs text-[#3d4947]">Registra tu cuenta y descubre quién tiene lo que buscas cerca de ti.</p>
          </header>

          {/* Registration Social Buttons */}
          <div className="grid grid-cols-2 gap-2">
            <button 
              id="onboarding-google-btn"
              type="button" 
              onClick={() => {
                setEmailText('f.delio@truek.com');
                addLog('Social-Auth: Simulación de Google OAuth activada', { email: 'f.delio@truek.com' });
              }}
              className="flex items-center justify-center gap-2 py-2 px-3 border border-[#bcc9c6] rounded-xl hover:bg-zinc-100 transition-all font-sans text-xs font-semibold text-[#191c1d]">
              <img 
                alt="Google" 
                className="w-4 h-4 rounded" 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuCd7P411dW60dnBGsYyBnUMRWypgzLKZ9IuNS4tn65pvDCVetuvSR1XMzXzaWhw5yDvKVc44Uf0HLxKLK-gx3lIosmITs8kqOYHiFgoyphXp4H8vEWWBWy4M-cgMG9bH8ZFkdcm-qmcEA3xIORNONznwADoNtEtw-yLqg7Ze-wB0aTgLUnIxp7EhS9sr_HJHxfejLGZWJVKOKIPFa4ew8Nnm546oMJdhGuG6crRGGdwMb0OWCxkLnCq" 
              />
              <span>Google</span>
            </button>
            <button 
              id="onboarding-apple-btn"
              type="button" 
              onClick={() => {
                setEmailText('apple.user@icloud.com');
                addLog('Social-Auth: Simulación de Apple ID activada', { email: 'apple.user@icloud.com' });
              }}
              className="flex items-center justify-center gap-2 py-2 px-3 bg-[#191c1d] text-white rounded-xl hover:opacity-90 transition-all font-sans text-xs font-semibold">
              <span className="material-symbols-outlined text-[16px] text-white">apps</span>
              <span>Apple</span>
            </button>
          </div>

          <div className="relative flex items-center justify-center">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-[#bcc9c6]/50"></div></div>
            <span className="relative bg-[#f8f9fa] px-2 text-[10px] font-bold text-[#6d7a77] uppercase tracking-wider">O utiliza tu email</span>
          </div>

          {/* Onboarding Credentials Form */}
          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label className="block text-[11px] font-semibold text-[#3d4947] mb-1" htmlFor="onboarding-email-input">Correo electrónico</label>
              <input 
                id="onboarding-email-input"
                name="email"
                type="email" 
                value={emailText}
                onChange={(e) => setEmailText(e.target.value)}
                placeholder="ejemplo@correo.com"
                required
                className="w-full px-4 py-2 text-sm bg-[#f3f4f5] border border-transparent rounded-xl focus:ring-2 focus:ring-[#00685f] focus:bg-white focus:outline-none transition-all placeholder:text-[#6d7a77]/55 text-zinc-900"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-[#3d4947] mb-1" htmlFor="onboarding-pass-input">Contraseña</label>
              <div className="relative">
                <input 
                  id="onboarding-pass-input"
                  name="password"
                  type={isPasswordVisible ? 'text' : 'password'} 
                  value={passwordText}
                  onChange={(e) => setPasswordText(e.target.value)}
                  placeholder="Mínimo 6 caracteres"
                  required
                  className="w-full px-4 py-2 text-sm bg-[#f3f4f5] border border-transparent rounded-xl focus:ring-2 focus:ring-[#00685f] focus:bg-white focus:outline-none transition-all placeholder:text-[#6d7a77]/55 text-zinc-900"
                />
                <button 
                  id="onboarding-toggle-pass-visibility"
                  type="button" 
                  onClick={() => setIsPasswordVisible(!isPasswordVisible)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6d7a77] hover:text-[#191c1d] active:scale-90 transition-all">
                  <span className="material-symbols-outlined text-[18px]">
                    {isPasswordVisible ? 'visibility_off' : 'visibility'}
                  </span>
                </button>
              </div>
            </div>
          </form>

          {/* Interactive Geolocation Widget */}
          <div className="p-3 bg-amber-50 border border-amber-200/60 rounded-xl flex items-center gap-3 shadow-sm hover:shadow transition-all">
            <div className="relative w-12 h-12 rounded-lg overflow-hidden bg-[#d9dadb] shrink-0 border border-amber-300">
              <img 
                alt="Map macro focus" 
                className="w-full h-full object-cover grayscale brightness-110" 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuCHTIbtgzbZf2SgIMYJCbc3S4uhLKW7VMiF9GbnjokPvMzkVLHvbH4sP4fbS5EkokaFt6vE_edtHb4at5mOOm_PDLeQmn74TDKCNOvvH5GDfG3ZQnvI2kj2t9GdddHgkUGYbXvvyXUpaIlswz-la0im9nSI69YmArHdfo7FQRBM2v5M6wLibPnHqkAp9pM1IG_P_uKEg3GRRVKQ1k3VuD2d1-l9UJUCjWK0h27P0BOAmWeiQh6MVS0I" 
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-2.5 h-2.5 bg-[#fea619] rounded-full animate-ping absolute"></div>
                <div className="w-2.5 h-2.5 bg-[#fea619] rounded-full shadow-[0_0_8px_rgba(254,166,25,0.8)]"></div>
              </div>
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-bold text-amber-700 tracking-wider uppercase">Zona de Trueque</span>
                <span className="text-[10px] text-[#00685f] font-semibold">Simulado</span>
              </div>
              
              {onboardingState.locationStatus === 'detecting' ? (
                <div className="flex items-center gap-2 mt-0.5">
                  <div className="w-3 h-3 border-2 border-[#00685f] border-t-transparent rounded-full animate-spin"></div>
                  <p className="text-xs text-[#191c1d] font-semibold animate-pulse">Buscando zona comercial cercana...</p>
                </div>
              ) : (
                <h4 id="onboarding-location-display" className="text-sm font-extrabold text-[#191c1d] truncate">
                  {onboardingState.locationText || 'No detectada'}
                </h4>
              )}

              <div className="flex items-center gap-1 mt-1">
                <span className="material-symbols-outlined text-[13px] text-[#00685f]">location_on</span>
                <span className="text-[10px] text-[#00685f] font-semibold">Localidad detectada vía GPS</span>
              </div>
            </div>
          </div>

          {/* Interests Chip Toggles */}
          <div>
            <h3 className="block text-[11px] font-semibold text-[#3d4947] mb-2">¿Qué te interesa intercambiar o donar?</h3>
            <div className="flex flex-wrap gap-1.5">
              {INITIAL_INTERESTS.map((interest) => {
                const isActive = onboardingState.selectedInterests.includes(interest);
                return (
                  <button
                    id={`interest-chip-${interest.toLowerCase().replace(' ', '-')}`}
                    key={interest}
                    type="button"
                    onClick={() => handleInterestToggle(interest)}
                    className={`px-3 py-1 text-[11px] font-semibold rounded-full border transition-all duration-200 active:scale-95 ${
                      isActive 
                        ? 'bg-[#008378] text-[#f4fffc] border-[#008378] shadow-sm font-bold' 
                        : 'bg-[#edeeef] text-[#3d4947] border-[#bcc9c6] hover:border-[#008378]'
                    }`}>
                    {interest}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Action Button CTA */}
        <div className="pt-4 mt-4 border-t border-[#edeeef]">
          <button
            id="onboarding-submit-btn"
            type="button"
            disabled={!isFormValid || onboardingState.locationStatus === 'detecting'}
            onClick={handleSubmit}
            className={`w-full py-3 bg-[#00685f] text-white rounded-xl font-semibold text-xs hover:bg-[#008378] active:scale-98 transform transition-all flex items-center justify-center gap-2 shadow-md ${
              (!isFormValid || onboardingState.locationStatus === 'detecting') ? 'opacity-50 cursor-not-allowed' : ''
            }`}>
            <span>Crear cuenta</span>
            <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
          </button>
        </div>
      </section>

      {/* Loading Overlay */}
      {isSubmitting && (
        <div id="onboarding-loading-overlay" className="absolute inset-0 z-40 bg-[#f8f9fa]/95 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center">
          <div className="w-12 h-12 border-[4px] border-[#00685f] border-t-transparent rounded-full animate-spin mb-4" />
          <h3 className="text-lg font-black text-[#191c1d] leading-tight">Creando Perfil Seguro...</h3>
          <p className="text-xs text-[#3d4947] mt-1 max-w-xs">Encriptando tus credenciales y registrando tu localización geoespacial en la blockchain simulada de TrueK.</p>
          
          <div className="w-32 h-[3px] bg-zinc-200 rounded-full mt-4 overflow-hidden relative">
            <div className="absolute top-0 bottom-0 left-0 bg-[#008378] animate-[shimmer_1.5s_infinite] w-12" style={{ animationTimingFunction: 'linear' }} />
          </div>
        </div>
      )}
    </div>
  );
}
