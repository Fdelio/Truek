/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { PublishState, PhotoUpload, FeedItem } from '../types';

interface PublishViewProps {
  publishState: PublishState;
  setPublishState: React.Dispatch<React.SetStateAction<PublishState>>;
  addFeedItem: (item: FeedItem) => void;
  onAdvance: () => void;
  addLog: (title: string, data: any) => void;
  userAvatar: string;
}

export default function PublishView({
  publishState,
  setPublishState,
  addFeedItem,
  onAdvance,
  addLog,
  userAvatar,
}: PublishViewProps) {
  const [photoProgress, setPhotoProgress] = useState<number | null>(null);
  const [isPublishing, setIsPublishing] = useState(false);

  const simulatePhotoUpload = (itemType: 'watch' | 'headphones') => {
    // Reset state first to start simulation clean
    setPhotoProgress(0);
    const newPhotoId = `photo_${Date.now()}`;
    const targetUrl = itemType === 'watch' 
      ? 'https://lh3.googleusercontent.com/aida-public/AB6AXuCCvrX8ETcHm6C-xvWyGp8GpZp2bJUP9i0z5Mry-xmZ6OBwwfXlGAyCHZovFtX8q-Jtqj0oQSClMhQDN7pn-qQSE5H6eNuhycOyd9xLgR-U5sz48tuo-mg1T3ZB7iyI9WrYD1rcG8qwIGIiilsWDFWTuuKfcFuEGyDJnYEvDleP1pp_wCHBSWrPlLKBLQvv6G6IFiTzUi5DBOOBX6ymRUJizDlU_SCBpYh0SvST7k3OPJcTn3oGRWYu'
      : 'https://lh3.googleusercontent.com/aida-public/AB6AXuCEc1kfubMN8qVowZAq0k4lhmDV7hy2yZlp4M7eraOlNtzOBYOeV9tJHoazeLsfISjMCa_jrC38hRqvyqCBYXV4GdRhe8udfOfZnxSJmV5UcahZoYipVD2-bGF1DZs9ZugDIJ_LJ3H_TH3EYAQkDB02SflA--suZc5tIWh8lcrennG0Z1uTIkRoN1oMXumA-kBeagq9zVEPBEy02nEWyHbMg_OI1dcBkTHobtMx1yECQpD7gDz8qtz3';
    
    const targetName = itemType === 'watch' ? 'Minimal_Watch.jpg' : 'AudioSonic_Overear.jpg';

    // Simulated upload progress intervals
    addLog('Posteo Inteligente: Iniciando subida de fotografía...', { fileName: targetName, size_kb: 2450 });

    let currentProgress = 0;
    const interval = setInterval(() => {
      currentProgress += 20;
      setPhotoProgress(currentProgress);
      
      if (currentProgress >= 100) {
        clearInterval(interval);
        
        // Finalize state uploading and trigger artificial intelligence tag suggestions
        const newPhoto: PhotoUpload = {
          id: newPhotoId,
          url: targetUrl,
          name: targetName,
          progress: 100,
          analyzed: true,
        };

        const suggestedTitle = itemType === 'watch' 
          ? 'Reloj de Muñeca de Diseño Minimalista' 
          : 'Auriculares Premium Bluetooth Active ANC';
        
        const suggestedDesc = itemType === 'watch'
          ? 'Reloj analógico impecable color blanco tiza con correa de cuero natural. Estética escandinava.'
          : 'Auriculares de diadema con cancelación activa de ruido huerfana de uso. Almohadillas extra de espuma viscoelástica.';

        setPublishState(prev => ({
          ...prev,
          photos: [...prev.photos, newPhoto],
          title: suggestedTitle,
          description: suggestedDesc,
          exchangeSearch: itemType === 'watch' ? 'Muebles de Living, Plantas de interior' : 'Zapatillas Deportivas Talla 41',
        }));

        setPhotoProgress(null);
        addLog('Posteo Inteligente: Análisis de IA completado. Autocompletado de metadatos y etiquetas.', {
          sourceImage: targetName,
          aiTags: ['Model ID: Watch-O-Matic-v4', 'Confidence: 98%'],
          predictedTitle: suggestedTitle,
          suggestedTags: ['Electrónica', 'Wearables', 'Premium']
        });
      }
    }, 150,);
  };

  const handlePublish = () => {
    if (!publishState.title) return;

    setIsPublishing(true);
    addLog('Posteo Inteligente: Enviando publicación a la base de datos local TrueK', {
      listingType: publishState.listingType,
      title: publishState.title,
      description: publishState.description,
      photosCount: publishState.photos.length,
    });

    setTimeout(() => {
      // Create new feed item dynamically to be prepended in discovery hub
      const mainPhoto = publishState.photos[0]?.url || 'https://images.unsplash.com/photo-1542291026-7eec264c27ff';
      const newItem: FeedItem = {
        id: `custom_item_${Date.now()}`,
        title: publishState.title,
        category: publishState.listingType === 'barter' ? 'Electrónica' : 'Muebles',
        type: publishState.listingType,
        distance: 0.1, // Uploaded by current user, virtually instantaneous
        userName: 'Tú (Prototipo)',
        userAvatar: userAvatar,
        image: mainPhoto,
        tag: 'RECIÉN PUBLICADO'
      };

      addFeedItem(newItem);
      setPublishState(prev => ({ ...prev, status: 'live' }));
      setIsPublishing(false);
      addLog('Posteo Inteligente: Publicación exitosa. Estado cambiado instantáneamente a "En línea".', {
        item_id: newItem.id,
        is_live: true,
        channel: 'Discovery Feed P2P'
      });
      onAdvance(); // Go to Discovery Hub to see it live!
    }, 2000);
  };

  const isFormValid = publishState.title.length > 3 && publishState.photos.length > 0;

  return (
    <div className="relative flex flex-col min-h-[700px] w-full bg-[#f8f9fa] rounded-2xl shadow-inner border border-zinc-200 overflow-y-auto max-h-[820px] p-5">
      {/* Top Header */}
      <div className="flex justify-between items-center pb-3 border-b border-zinc-200">
        <div>
          <h2 className="text-xl font-black text-[#191c1d] leading-none mb-1">Crear Publicación</h2>
          <p className="text-xs text-[#3d4947]">Asistente "Posteo Inteligente" asistido por IA</p>
        </div>
        <div className="flex items-center gap-1.5 bg-[#e1e0ff] text-[#07006c] px-3 py-1 rounded-full text-[10px] font-bold animate-pulse">
          <span className="material-symbols-outlined text-[14px]">psychology</span>
          <span>IA Activa</span>
        </div>
      </div>

      {/* Barter/Donation Selector Toggle */}
      <div className="my-5 flex flex-col items-center gap-2">
        <label className="text-[11px] font-bold text-[#3d4947] tracking-wider uppercase">Tipo de Intercambio</label>
        <div className="bg-[#edeeef] p-1 rounded-full flex w-full max-w-xs shadow-inner relative overflow-hidden">
          <button 
            type="button" 
            onClick={() => {
              setPublishState(prev => ({ ...prev, listingType: 'barter' }));
              addLog('Posteo: Tipo cambiado a "Trueque"', { accentColor: 'Teal (#00685f)' });
            }}
            id="publish-toggle-barter"
            className={`flex-1 py-1.5 rounded-full text-xs font-bold transition-all duration-300 z-10 ${
              publishState.listingType === 'barter'
                ? 'bg-[#008378] text-[#f4fffc] shadow-md'
                : 'text-[#3d4947] hover:bg-[#bcc9c6]/20'
            }`}>
            Trueque
          </button>
          
          <button 
            type="button" 
            onClick={() => {
              setPublishState(prev => ({ ...prev, listingType: 'donation' }));
              addLog('Posteo: Tipo cambiado a "Donación/Regalo"', { accentColor: 'Orange (#fea619)' });
            }}
            id="publish-toggle-donation"
            className={`flex-1 py-1.5 rounded-full text-xs font-bold transition-all duration-300 z-10 ${
              publishState.listingType === 'donation'
                ? 'bg-[#fea619] text-[#684000] shadow-md'
                : 'text-[#3d4947] hover:bg-[#bcc9c6]/20'
            }`}>
            Donación
          </button>
        </div>
      </div>

      {/* Dynamic Colored Border Section */}
      <div className={`p-4 rounded-xl border bg-white shadow-sm space-y-4 transition-all duration-300 ${
        publishState.listingType === 'barter' ? 'border-[#008378]/25' : 'border-[#fea619]/25'
      }`}>
        {/* Media Upload and Progress Rings */}
        <div>
          <span className="block text-[11px] font-bold text-[#3d4947] mb-2 uppercase tracking-wide">Galería de Fotos</span>
          
          <div className="grid grid-cols-3 gap-2.5">
            {/* Simulation Uploader Triggers */}
            <div className="flex flex-col gap-1.5">
              <button 
                id="publish-simulate-upload-combo"
                type="button" 
                onClick={() => simulatePhotoUpload('watch')}
                className="aspect-square rounded-xl border-2 border-dashed border-zinc-300 hover:border-[#008378] hover:bg-[#008378]/5 flex flex-col items-center justify-center gap-1 group active:scale-95 transition-all text-center p-2">
                <span className="material-symbols-outlined text-[20px] text-[#00685f] group-hover:scale-110 duration-200">watch</span>
                <span className="text-[9px] font-bold leading-normal text-zinc-600">Preset Reloj</span>
              </button>
              <button 
                id="publish-simulate-headphones"
                type="button" 
                onClick={() => simulatePhotoUpload('headphones')}
                className="aspect-square rounded-xl border-2 border-dashed border-zinc-300 hover:border-amber-500 hover:bg-amber-50/70 flex flex-col items-center justify-center gap-1 group active:scale-95 transition-all text-center p-2">
                <span className="material-symbols-outlined text-[20px] text-amber-600 group-hover:scale-110 duration-200">headphones</span>
                <span className="text-[9px] font-bold leading-normal text-zinc-600">Preset Auric</span>
              </button>
            </div>

            {/* Active upload ring overlay */}
            {photoProgress !== null && (
              <div id="publish-photo-upload-container" className="relative aspect-square rounded-xl overflow-hidden bg-zinc-800 flex items-center justify-center border border-zinc-650">
                <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center text-white p-2">
                  <svg className="w-10 h-10 -rotate-90">
                    <circle cx="20" cy="20" r="16" fill="transparent" stroke="rgba(255,255,255,0.2)" strokeWidth="3" />
                    <circle 
                      cx="20" 
                      cy="20" 
                      r="16" 
                      fill="transparent" 
                      stroke="#89f5e7" 
                      strokeWidth="3" 
                      strokeDasharray="100.5" 
                      strokeDashoffset={100.5 - photoProgress} 
                      className="transition-all duration-150"
                    />
                  </svg>
                  <span className="text-[9px] font-bold mt-1 text-cyan-300 animate-pulse">{photoProgress}%</span>
                </div>
              </div>
            )}

            {/* Render uploaded image thumbnails */}
            {publishState.photos.map((photo) => (
              <div key={photo.id} className="relative aspect-square rounded-xl overflow-hidden group border border-[#bcc9c6]/40 shadow-sm">
                <img alt="Thumbnail" className="w-full h-full object-cover" src={photo.url} />
                <div className="absolute inset-x-0 bottom-0 bg-black/50 py-0.5 px-1 text-center">
                  <span id="publish-thumbnail-analyzed-badge" className="text-[8px] font-bold text-teal-300 uppercase tracking-widest">ANALIZADO</span>
                </div>
                <button 
                  type="button" 
                  onClick={() => {
                    setPublishState(prev => ({ ...prev, photos: prev.photos.filter(p => p.id !== photo.id) }));
                    addLog('Posteo: Foto eliminada de la galería', { photoId: photo.id });
                  }}
                  className="absolute top-1 right-1 bg-red-600 text-white p-1 rounded-full shadow hover:bg-red-700 transition-colors">
                  <span className="material-symbols-outlined text-[10px] leading-none block">close</span>
                </button>
              </div>
            ))}
          </div>

          <p className="text-[10px] text-[#4648d4] font-medium italic mt-2.5 flex items-center gap-1">
            <span className="material-symbols-outlined text-[14px]">auto_awesome</span>
            <span>Intente simular el "Preset Reloj" o "Preset Auric" para verificar el flujo de autocompletado inteligente.</span>
          </p>
        </div>

        {/* Text Form Fields */}
        <div className="space-y-3">
          <div>
            <label className="block text-[11px] font-semibold text-[#3d4947] mb-1" htmlFor="publish-title-input">Título de la publicación</label>
            <input 
              id="publish-title-input"
              type="text" 
              value={publishState.title}
              onChange={(e) => setPublishState(prev => ({ ...prev, title: e.target.value }))}
              placeholder="Ej. Reloj minimalist o similar..."
              className="w-full px-4 py-2 text-sm bg-[#f3f4f5] border-none rounded-xl focus:ring-2 focus:ring-[#00685f] focus:bg-white focus:outline-none transition-all text-zinc-900"
            />
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-[#3d4947] mb-1" htmlFor="publish-desc-input">Descripción del artículo</label>
            <textarea 
              id="publish-desc-input"
              value={publishState.description}
              onChange={(e) => setPublishState(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Detalles sobre uso, antigüedad, caja, cables..."
              rows={3}
              className="w-full px-4 py-2 text-sm bg-[#f3f4f5] border-none rounded-xl focus:ring-2 focus:ring-[#00685f] focus:bg-white focus:outline-none transition-all text-zinc-900"
            />
          </div>

          {/* Conditional Trade Value Requirement Box */}
          {publishState.listingType === 'barter' && (
            <div id="publish-exchange-container" className="space-y-1.5">
              <label className="block text-[11px] font-semibold text-[#3d4947]" htmlFor="publish-exchange-input">¿Qué buscas a cambio?</label>
              <div className="relative">
                <input 
                  id="publish-exchange-input"
                  type="text" 
                  value={publishState.exchangeSearch}
                  onChange={(e) => setPublishState(prev => ({ ...prev, exchangeSearch: e.target.value }))}
                  placeholder="Ej. Consolas de videojuegos, Auriculares..."
                  className="w-full px-4 py-2 pr-10 text-sm bg-[#f3f4f5] border-none rounded-xl focus:ring-2 focus:ring-[#00685f] focus:bg-white focus:outline-none transition-all text-zinc-900"
                />
                <span className="material-symbols-outlined text-[#00685f] absolute right-3 top-1/2 -translate-y-1/2">swap_horiz</span>
              </div>
              <div className="flex gap-1">
                {['Abierto a Todo', 'Tecnología', 'Bicicletas'].map((chip) => (
                  <button
                    key={chip}
                    type="button"
                    onClick={() => {
                      setPublishState(prev => ({ ...prev, exchangeSearch: chip }));
                      addLog(`Posteo: Preferencia autoseleccionada: "${chip}"`, {});
                    }}
                    className="px-2.5 py-0.5 rounded-full bg-[#008378]/10 text-[#00685f] border border-[#008378]/20 text-[9px] font-semibold hover:bg-[#008378]/20 transition-all">
                    {chip}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Action CTA Block */}
      <div className="mt-auto pt-4 border-t border-[#edeeef] flex gap-3">
        <button 
          id="publish-save-draft"
          type="button"
          onClick={() => {
            setPublishState(prev => ({ ...prev, status: 'draft' }));
            addLog('Posteo: Cambios guardados como borrador técnico offline', { stamp: Date.now() });
          }}
          className="flex-1 bg-[#e7e8e9] text-[#191c1d] py-3 rounded-xl font-bold text-xs hover:bg-[#d9dadb] active:scale-95 transition-all text-center">
          Guardar borrador
        </button>

        <button 
          id="publish-submit-btn"
          type="button" 
          disabled={!isFormValid}
          onClick={handlePublish}
          className={`flex-[2] text-white py-3 rounded-xl font-bold text-xs shadow-md active:scale-95 transition-all flex items-center justify-center gap-2 ${
            isFormValid 
              ? publishState.listingType === 'barter' ? 'bg-[#00685f] hover:bg-[#008378]' : 'bg-[#fea619] hover:bg-amber-650 !text-slate-900' 
              : 'bg-zinc-300 text-zinc-500 cursor-not-allowed'
          }`}>
          <span>Publicar ahora</span>
          <span className="material-symbols-outlined text-[16px]">rocket_launch</span>
        </button>
      </div>

      {/* Full screen simulated web-endpoint delay loader */}
      {isPublishing && (
        <div id="publish-loading-overlay" className="absolute inset-0 z-40 bg-[#f8f9fa]/90 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center">
          <div className="w-14 h-14 border-[4px] border-[#00685f] border-t-transparent rounded-full animate-spin mb-4" />
          <h3 className="text-base font-extrabold text-[#191c1d] leading-none">Publicando Artículo "En Línea"...</h3>
          <p className="text-xs text-[#3d4947] mt-1 max-w-xs">Registrando tags, cargando imágenes al almacenamiento simulado e indexando nodo geolocalizado.</p>
        </div>
      )}
    </div>
  );
}
